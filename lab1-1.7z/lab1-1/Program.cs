﻿using System;
using System.Collections.Generic;

namespace lab1_1
{
    class Program
    {
        static void Main()
        {
            double z1, z2;
            Console.Write("Введите а: ");
            double a = double.Parse(Console.ReadLine());

            z1 = Math.Cos(a) + Math.Sin(a) + Math.Cos(3.0 * a) + Math.Sin(3.0 * a);
            z2 = 1.0/4.0 - 1.0/4.0 * Math.Sin(5.0/2.0 * Math.PI - 8.0 * a);

            Console.WriteLine("z1 = {0} \nz2 = {1}", z1, z2);
        }
    }
}